import { useState, useCallback } from "react";
import { toast } from "sonner";

export interface CSVRow {
  [key: string]: string | number;
}

export interface CSVData {
  headers: string[];
  rows: CSVRow[];
}

export const useCSVUpload = () => {
  const [data, setData] = useState<CSVData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  const parseCSV = useCallback((text: string): CSVData => {
    const lines = text.trim().split("\n");
    if (lines.length < 2) {
      throw new Error("CSV must have at least a header row and one data row");
    }

    const headers = lines[0].split(",").map((h) => h.trim().replace(/"/g, ""));
    const rows: CSVRow[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map((v) => v.trim().replace(/"/g, ""));
      if (values.length !== headers.length) continue;

      const row: CSVRow = {};
      headers.forEach((header, index) => {
        const value = values[index];
        // Try to parse as number
        const numValue = parseFloat(value);
        row[header] = isNaN(numValue) ? value : numValue;
      });
      rows.push(row);
    }

    return { headers, rows };
  }, []);

  const handleFileUpload = useCallback(
    (file: File) => {
      if (!file.name.endsWith(".csv")) {
        toast.error("Please upload a CSV file");
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast.error("File size must be less than 5MB");
        return;
      }

      setIsLoading(true);
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          const parsed = parseCSV(text);
          setData(parsed);
          setFileName(file.name);
          toast.success(`Loaded ${parsed.rows.length} records from ${file.name}`);
        } catch (error) {
          toast.error(error instanceof Error ? error.message : "Failed to parse CSV");
        } finally {
          setIsLoading(false);
        }
      };

      reader.onerror = () => {
        toast.error("Failed to read file");
        setIsLoading(false);
      };

      reader.readAsText(file);
    },
    [parseCSV]
  );

  const clearData = useCallback(() => {
    setData(null);
    setFileName(null);
  }, []);

  return {
    data,
    isLoading,
    fileName,
    handleFileUpload,
    clearData,
  };
};
