import React, { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import Navbar from "@/components/Navbar";
import PredictionChart from "@/components/PredictionChart";
import InsightCard from "@/components/InsightCard";
import Chatbot from "@/components/Chatbot";
import { Clock, CloudRain, Sun, Cloud, Brain, Zap, TrendingUp } from "lucide-react";
import { toast } from "sonner";

interface HourlyPredictionProps {
  onLogout: () => void;
}

const HourlyPrediction = ({ onLogout }: HourlyPredictionProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [season, setSeason] = useState("");
  const [weather, setWeather] = useState("");
  const [workingDay, setWorkingDay] = useState("");
  const [temperature, setTemperature] = useState([22]);

  const hourlyData = useMemo(() => {
    if (!showResults) return [];
    const basePattern = [15, 12, 8, 5, 4, 8, 25, 85, 120, 95, 70, 65, 80, 75, 68, 72, 95, 145, 165, 130, 85, 55, 35, 22];
    const weatherMultiplier = weather === "clear" ? 1.2 : weather === "cloudy" ? 1 : weather === "rainy" ? 0.5 : 0.8;
    const workingMultiplier = workingDay === "yes" ? 1.3 : 0.9;
    const tempFactor = Math.max(0.5, Math.min(1.3, 1 + (temperature[0] - 20) / 50));
    return basePattern.map((base, hour) => ({
      label: `${hour.toString().padStart(2, "0")}:00`,
      value: Math.round(base * weatherMultiplier * workingMultiplier * tempFactor + Math.random() * 10),
    }));
  }, [showResults, weather, workingDay, temperature]);

  const peakHour = useMemo(() => hourlyData.length ? hourlyData.reduce((max, curr) => curr.value > max.value ? curr : max, hourlyData[0]) : null, [hourlyData]);
  const totalDemand = useMemo(() => hourlyData.reduce((sum, curr) => sum + curr.value, 0), [hourlyData]);

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!season || !weather || !workingDay) { toast.error("Please configure all parameters"); return; }
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setShowResults(true);
    setIsLoading(false);
    toast.success("AI analysis complete!");
  };

  const weatherIcon = weather === "clear" ? Sun : weather === "cloudy" ? Cloud : CloudRain;

  return (
    <div className="min-h-screen bg-background">
      <Navbar onLogout={onLogout} />
      <main className="container mx-auto px-4 py-6 pb-24">
        <div className="mb-6 animate-fade-in">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 rounded-xl glass-card neon-blue">
              <Clock className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-3xl font-extrabold text-foreground tracking-tight">Hourly Prediction</h1>
          </div>
          <p className="text-muted-foreground">AI-powered hourly demand analysis for optimized operations</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="glass-card rounded-2xl p-6 animate-slide-up sticky top-24">
              <h2 className="text-lg font-bold text-foreground mb-5 flex items-center gap-2">
                <Brain className="w-4 h-4 text-primary" />
                AI Parameters
              </h2>
              <form onSubmit={handlePredict} className="space-y-5">
                <div className="space-y-2"><Label className="text-foreground">Season</Label><Select value={season} onValueChange={setSeason}><SelectTrigger className="bg-muted/50 border-border"><SelectValue placeholder="Select season" /></SelectTrigger><SelectContent><SelectItem value="spring">🌸 Spring</SelectItem><SelectItem value="summer">☀️ Summer</SelectItem><SelectItem value="fall">🍂 Fall</SelectItem><SelectItem value="winter">❄️ Winter</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label className="text-foreground">Weather Condition</Label><Select value={weather} onValueChange={setWeather}><SelectTrigger className="bg-muted/50 border-border"><SelectValue placeholder="Select weather" /></SelectTrigger><SelectContent><SelectItem value="clear">☀️ Clear</SelectItem><SelectItem value="cloudy">☁️ Cloudy</SelectItem><SelectItem value="rainy">🌧️ Rainy</SelectItem><SelectItem value="heavy">⛈️ Heavy Rain</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label className="text-foreground">Working Day</Label><Select value={workingDay} onValueChange={setWorkingDay}><SelectTrigger className="bg-muted/50 border-border"><SelectValue placeholder="Select type" /></SelectTrigger><SelectContent><SelectItem value="yes">Yes - Weekday</SelectItem><SelectItem value="no">No - Weekend/Holiday</SelectItem></SelectContent></Select></div>
                <div className="space-y-3"><Label className="text-foreground flex justify-between"><span>Temperature</span><span className="text-primary font-bold">{temperature[0]}°C</span></Label><Slider value={temperature} onValueChange={setTemperature} min={-5} max={40} step={1} className="py-2" /></div>
                <Button type="submit" className="w-full h-12 gradient-primary font-bold hover:shadow-glow transition-all" disabled={isLoading}>
                  {isLoading ? <span className="flex items-center gap-2"><Brain className="w-5 h-5 animate-analyzing" />Analyzing...</span> : <span className="flex items-center gap-2"><Zap className="w-5 h-5" />Generate Forecast</span>}
                </Button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-5">
            {!showResults ? (
              <div className="glass-card rounded-2xl p-12 text-center animate-slide-up">
                <div className="w-20 h-20 glass-card rounded-2xl flex items-center justify-center mx-auto mb-6"><Clock className="w-10 h-10 text-primary/50" /></div>
                <h3 className="text-xl font-bold text-foreground mb-2">Ready for Analysis</h3>
                <p className="text-muted-foreground">Configure parameters and let our AI generate your hourly forecast</p>
              </div>
            ) : (
              <>
                <div className="glass-card rounded-2xl p-5 animate-slide-up">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-foreground">Hourly Demand Curve</h3>
                    {weather && <div className="flex items-center gap-2 text-sm px-3 py-1 rounded-full bg-muted/50">{React.createElement(weatherIcon, { className: "w-4 h-4 text-primary" })}<span className="text-muted-foreground capitalize">{weather}</span></div>}
                  </div>
                  <PredictionChart data={hourlyData} type="area" />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="glass-card rounded-xl p-4 text-center animate-slide-up animate-delay-100"><p className="text-xs text-muted-foreground mb-1">Peak Hour</p><p className="text-2xl font-bold text-primary">{peakHour?.label}</p><p className="text-xs text-secondary font-medium mt-1">{peakHour?.value} rentals</p></div>
                  <div className="glass-card rounded-xl p-4 text-center animate-slide-up animate-delay-200"><p className="text-xs text-muted-foreground mb-1">Total Daily</p><p className="text-2xl font-bold text-foreground">{totalDemand.toLocaleString()}</p></div>
                  <div className="glass-card rounded-xl p-4 text-center animate-slide-up animate-delay-300"><p className="text-xs text-muted-foreground mb-1">Avg Hourly</p><p className="text-2xl font-bold text-foreground">{Math.round(totalDemand / 24)}</p></div>
                </div>
                <div className="space-y-3 animate-slide-up animate-delay-400">
                  <InsightCard type="peak" title="Peak Period Alert" description={`High demand expected at ${peakHour?.label} with ~${peakHour?.value} predicted rentals. Consider repositioning bikes.`} />
                  <InsightCard type="tip" title="AI Recommendation" description={workingDay === "yes" ? "Commuter patterns detected. Expect rush at 8-9 AM and 5-7 PM." : "Weekend pattern - gradual increase from late morning to afternoon."} />
                </div>
              </>
            )}
          </div>
        </div>
      </main>
      <Chatbot />
    </div>
  );
};

export default HourlyPrediction;
