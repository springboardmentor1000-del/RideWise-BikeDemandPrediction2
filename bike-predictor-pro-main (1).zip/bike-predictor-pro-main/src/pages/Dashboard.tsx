import { Clock, Calendar, TrendingUp, Activity, Target, Bike, AlertTriangle, Zap, MapPin, Brain, Gauge } from "lucide-react";
import MetricCard from "@/components/MetricCard";
import ActionCard from "@/components/ActionCard";
import Navbar from "@/components/Navbar";
import BikeMap from "@/components/BikeMap";
import AlertCard from "@/components/AlertCard";
import Chatbot from "@/components/Chatbot";

interface DashboardProps {
  onLogout: () => void;
}

const Dashboard = ({ onLogout }: DashboardProps) => {
  const metrics = [
    {
      title: "Active Bikes",
      value: "847",
      subtitle: "Currently on the road",
      icon: Bike,
      color: "blue" as const,
    },
    {
      title: "Demand Pressure",
      value: "High",
      subtitle: "Index: 8.4 / 10",
      icon: Gauge,
      color: "orange" as const,
    },
    {
      title: "Peak Window",
      value: "5-7 PM",
      subtitle: "In 3 hours",
      icon: Clock,
      color: "green" as const,
    },
    {
      title: "AI Confidence",
      value: "94.2%",
      subtitle: "Model accuracy",
      icon: Brain,
      color: "purple" as const,
    },
  ];

  const actions = [
    {
      title: "Hourly Demand Prediction",
      description:
        "AI-powered hourly analysis. Identify peak periods and optimize bike distribution for maximum efficiency.",
      icon: Clock,
      href: "/hourly",
    },
    {
      title: "Daily Demand Forecast",
      description:
        "Multi-day forecasting engine. Strategic insights for fleet management and resource allocation.",
      icon: Calendar,
      href: "/daily",
    },
  ];

  const alerts = [
    {
      type: "demand" as const,
      title: "Surge Zone Detected",
      description: "Downtown experiencing 40% above normal demand pressure",
      value: "+40%",
    },
    {
      type: "warning" as const,
      title: "Low Inventory Alert",
      description: "Station #12 (Central Park) critically low",
      value: "3 bikes",
    },
    {
      type: "time" as const,
      title: "Rush Hour Imminent",
      description: "Evening peak begins in 2 hours - prepare fleet",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar onLogout={onLogout} />

      <main className="container mx-auto px-4 py-6 pb-24">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-extrabold text-foreground tracking-tight">
              Command Center
            </h1>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full glass-card text-xs">
              <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
              <span className="text-secondary font-medium">Live</span>
            </div>
          </div>
          <p className="text-muted-foreground">
            Real-time bike sharing intelligence powered by machine learning
          </p>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {metrics.map((metric, index) => (
            <MetricCard
              key={metric.title}
              {...metric}
              delay={index * 100}
            />
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Map Section */}
          <div className="lg:col-span-2 animate-slide-up" style={{ animationDelay: "200ms" }}>
            <div className="glass-card rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Live Fleet Map
                </h2>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground px-3 py-1.5 rounded-full bg-muted/50 flex items-center gap-2">
                    <span className="w-2 h-2 bg-secondary rounded-full animate-pulse" />
                    Real-time tracking
                  </span>
                </div>
              </div>
              <BikeMap />
            </div>
          </div>

          {/* Alerts Section */}
          <div className="space-y-4 animate-slide-up" style={{ animationDelay: "300ms" }}>
            <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-accent" />
              Active Alerts
            </h2>
            <div className="space-y-3">
              {alerts.map((alert, index) => (
                <AlertCard
                  key={alert.title}
                  {...alert}
                  delay={400 + index * 100}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Prediction Tools */}
        <div className="mb-8">
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            AI Prediction Engine
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {actions.map((action, index) => (
              <ActionCard
                key={action.title}
                {...action}
                delay={500 + index * 100}
              />
            ))}
          </div>
        </div>

        {/* How it works */}
        <div className="glass-card rounded-2xl p-6 animate-slide-up" style={{ animationDelay: "700ms" }}>
          <h3 className="text-lg font-bold text-foreground mb-6 flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            How RideWise Works
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 group">
              <div className="w-14 h-14 glass-card rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:neon-blue transition-all duration-300">
                <span className="text-primary font-bold text-xl">1</span>
              </div>
              <h4 className="font-bold text-foreground mb-2">Configure Parameters</h4>
              <p className="text-sm text-muted-foreground">
                Set conditions like weather, time, and season for accurate predictions
              </p>
            </div>
            <div className="text-center p-4 group">
              <div className="w-14 h-14 glass-card rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:neon-green transition-all duration-300">
                <span className="text-secondary font-bold text-xl">2</span>
              </div>
              <h4 className="font-bold text-foreground mb-2">AI Analysis</h4>
              <p className="text-sm text-muted-foreground">
                Our ML model processes patterns and generates forecasts instantly
              </p>
            </div>
            <div className="text-center p-4 group">
              <div className="w-14 h-14 glass-card rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:neon-orange transition-all duration-300">
                <span className="text-accent font-bold text-xl">3</span>
              </div>
              <h4 className="font-bold text-foreground mb-2">Get Insights</h4>
              <p className="text-sm text-muted-foreground">
                Receive actionable recommendations for smarter fleet operations
              </p>
            </div>
          </div>
        </div>
      </main>

      <Chatbot />
    </div>
  );
};

export default Dashboard;
