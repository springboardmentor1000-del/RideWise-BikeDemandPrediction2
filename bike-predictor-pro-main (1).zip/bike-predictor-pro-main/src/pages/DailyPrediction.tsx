import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import Navbar from "@/components/Navbar";
import PredictionChart from "@/components/PredictionChart";
import InsightCard from "@/components/InsightCard";
import Chatbot from "@/components/Chatbot";
import { Calendar, TrendingUp, TrendingDown, Brain, Zap, Target } from "lucide-react";
import { toast } from "sonner";

interface DailyPredictionProps { onLogout: () => void; }

const DailyPrediction = ({ onLogout }: DailyPredictionProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [month, setMonth] = useState("");
  const [season, setSeason] = useState("");
  const [avgTemperature, setAvgTemperature] = useState([20]);
  const [forecastDays, setForecastDays] = useState("7");

  const dailyData = useMemo(() => {
    if (!showResults) return [];
    const days = parseInt(forecastDays) || 7;
    const baseMultiplier = season === "summer" ? 1.4 : season === "spring" ? 1.1 : season === "fall" ? 0.95 : 0.7;
    const tempFactor = Math.max(0.5, Math.min(1.3, 1 + (avgTemperature[0] - 18) / 40));
    const dayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const today = new Date();
    return Array.from({ length: days }, (_, i) => { const date = new Date(today); date.setDate(date.getDate() + i); const isWeekend = date.getDay() === 0 || date.getDay() === 6; const baseValue = isWeekend ? 1200 : 1600; return { label: `${dayNames[(today.getDay() + i) % 7]} ${date.getDate()}`, value: Math.round(baseValue * baseMultiplier * tempFactor + (Math.random() - 0.5) * 200) }; });
  }, [showResults, season, avgTemperature, forecastDays]);

  const totalDemand = useMemo(() => dailyData.reduce((sum, curr) => sum + curr.value, 0), [dailyData]);
  const avgDemand = useMemo(() => dailyData.length ? Math.round(totalDemand / dailyData.length) : 0, [dailyData, totalDemand]);
  const peakDay = useMemo(() => dailyData.length ? dailyData.reduce((max, curr) => curr.value > max.value ? curr : max, dailyData[0]) : null, [dailyData]);
  const trend = useMemo(() => { if (dailyData.length < 2) return 0; const firstHalf = dailyData.slice(0, Math.floor(dailyData.length / 2)); const secondHalf = dailyData.slice(Math.floor(dailyData.length / 2)); const firstAvg = firstHalf.reduce((s, c) => s + c.value, 0) / firstHalf.length; const secondAvg = secondHalf.reduce((s, c) => s + c.value, 0) / secondHalf.length; return ((secondAvg - firstAvg) / firstAvg) * 100; }, [dailyData]);

  const handlePredict = async (e: React.FormEvent) => { e.preventDefault(); if (!month || !season) { toast.error("Please configure all parameters"); return; } setIsLoading(true); await new Promise((resolve) => setTimeout(resolve, 1500)); setShowResults(true); setIsLoading(false); toast.success("AI forecast generated!"); };

  return (
    <div className="min-h-screen bg-background">
      <Navbar onLogout={onLogout} />
      <main className="container mx-auto px-4 py-6 pb-24">
        <div className="mb-6 animate-fade-in">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 rounded-xl glass-card neon-green"><Calendar className="w-5 h-5 text-secondary" /></div>
            <h1 className="text-3xl font-extrabold text-foreground tracking-tight">Daily Forecast</h1>
          </div>
          <p className="text-muted-foreground">Multi-day demand forecasting for strategic fleet planning</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="glass-card rounded-2xl p-6 animate-slide-up sticky top-24">
              <h2 className="text-lg font-bold text-foreground mb-5 flex items-center gap-2"><Brain className="w-4 h-4 text-secondary" />Forecast Settings</h2>
              <form onSubmit={handlePredict} className="space-y-5">
                <div className="space-y-2"><Label className="text-foreground">Month</Label><Select value={month} onValueChange={setMonth}><SelectTrigger className="bg-muted/50 border-border"><SelectValue placeholder="Select month" /></SelectTrigger><SelectContent><SelectItem value="january">January</SelectItem><SelectItem value="february">February</SelectItem><SelectItem value="march">March</SelectItem><SelectItem value="april">April</SelectItem><SelectItem value="may">May</SelectItem><SelectItem value="june">June</SelectItem><SelectItem value="july">July</SelectItem><SelectItem value="august">August</SelectItem><SelectItem value="september">September</SelectItem><SelectItem value="october">October</SelectItem><SelectItem value="november">November</SelectItem><SelectItem value="december">December</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label className="text-foreground">Season</Label><Select value={season} onValueChange={setSeason}><SelectTrigger className="bg-muted/50 border-border"><SelectValue placeholder="Select season" /></SelectTrigger><SelectContent><SelectItem value="spring">🌸 Spring</SelectItem><SelectItem value="summer">☀️ Summer</SelectItem><SelectItem value="fall">🍂 Fall</SelectItem><SelectItem value="winter">❄️ Winter</SelectItem></SelectContent></Select></div>
                <div className="space-y-3"><Label className="text-foreground flex justify-between"><span>Avg Temperature</span><span className="text-secondary font-bold">{avgTemperature[0]}°C</span></Label><Slider value={avgTemperature} onValueChange={setAvgTemperature} min={-5} max={40} step={1} className="py-2" /></div>
                <div className="space-y-2"><Label className="text-foreground">Forecast Period</Label><Select value={forecastDays} onValueChange={setForecastDays}><SelectTrigger className="bg-muted/50 border-border"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="7">7 Days</SelectItem><SelectItem value="14">14 Days</SelectItem><SelectItem value="30">30 Days</SelectItem></SelectContent></Select></div>
                <Button type="submit" className="w-full h-12 gradient-secondary text-secondary-foreground font-bold hover:shadow-glow transition-all" disabled={isLoading}>
                  {isLoading ? <span className="flex items-center gap-2"><Brain className="w-5 h-5 animate-analyzing" />Processing...</span> : <span className="flex items-center gap-2"><Zap className="w-5 h-5" />Generate Forecast</span>}
                </Button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-5">
            {!showResults ? (
              <div className="glass-card rounded-2xl p-12 text-center animate-slide-up">
                <div className="w-20 h-20 glass-card rounded-2xl flex items-center justify-center mx-auto mb-6"><Calendar className="w-10 h-10 text-secondary/50" /></div>
                <h3 className="text-xl font-bold text-foreground mb-2">Ready for Forecasting</h3>
                <p className="text-muted-foreground">Configure parameters to generate your multi-day demand forecast</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="glass-card rounded-xl p-4 text-center animate-slide-up"><p className="text-xs text-muted-foreground mb-1">Total Demand</p><p className="text-xl font-bold text-foreground">{totalDemand.toLocaleString()}</p></div>
                  <div className="glass-card rounded-xl p-4 text-center animate-slide-up animate-delay-100"><p className="text-xs text-muted-foreground mb-1">Daily Avg</p><p className="text-xl font-bold text-foreground">{avgDemand.toLocaleString()}</p></div>
                  <div className="glass-card rounded-xl p-4 text-center animate-slide-up animate-delay-200"><p className="text-xs text-muted-foreground mb-1">Peak Day</p><p className="text-xl font-bold text-secondary">{peakDay?.label}</p></div>
                  <div className="glass-card rounded-xl p-4 text-center animate-slide-up animate-delay-300"><p className="text-xs text-muted-foreground mb-1">Trend</p><div className="flex items-center justify-center gap-1">{trend > 0 ? <TrendingUp className="w-4 h-4 text-secondary" /> : <TrendingDown className="w-4 h-4 text-destructive" />}<p className={`text-xl font-bold ${trend > 0 ? "text-secondary" : "text-destructive"}`}>{trend > 0 ? "+" : ""}{trend.toFixed(1)}%</p></div></div>
                </div>
                <div className="glass-card rounded-2xl p-5 animate-slide-up animate-delay-400">
                  <div className="flex items-center justify-between mb-4"><h3 className="text-lg font-bold text-foreground flex items-center gap-2"><Target className="w-5 h-5 text-secondary" />Daily Forecast Curve</h3><span className="text-sm text-muted-foreground px-3 py-1 rounded-full bg-muted/50">{forecastDays} days</span></div>
                  <PredictionChart data={dailyData} type="area" />
                </div>
                <div className="space-y-3 animate-slide-up animate-delay-500">
                  <InsightCard type="peak" title="Peak Day Alert" description={`${peakDay?.label} shows highest demand with ${peakDay?.value.toLocaleString()} predicted rentals.`} />
                  <InsightCard type="tip" title="Strategic Insight" description={season === "summer" ? "Summer drives peak demand - ideal period for fleet expansion." : season === "winter" ? "Winter reduces demand - focus on maintenance and cost optimization." : "Moderate seasonal conditions - maintain balanced fleet operations."} />
                </div>
              </>
            )}
          </div>
        </div>
      </main>
      <Chatbot />
    </div>
  );
};

export default DailyPrediction;
