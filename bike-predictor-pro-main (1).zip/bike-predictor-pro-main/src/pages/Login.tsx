import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Bike, Eye, EyeOff, Lock, User, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface LoginProps {
  onLogin: () => void;
}

const Login = ({ onLogin }: LoginProps) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 800));
    setIsTransitioning(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    toast.success("Welcome to RideWise!");
    onLogin();
    navigate("/dashboard");
    setIsLoading(false);
  };

  return (
    <div className={`min-h-screen flex items-center justify-center bg-background relative overflow-hidden transition-all duration-700 ${isTransitioning ? "opacity-0 scale-110" : ""}`}>
      {/* Animated road background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
        
        {/* Animated road lines */}
        <div className="absolute bottom-0 left-0 right-0 h-32 opacity-20">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="absolute h-1 bg-gradient-to-r from-transparent via-primary to-transparent animate-road-lines"
              style={{
                top: `${i * 20}%`,
                width: "200px",
                animationDelay: `${i * 0.5}s`,
                left: `${i * 15}%`,
              }}
            />
          ))}
        </div>
        
        {/* Radial glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] gradient-radial-glow" />
        
        {/* Floating elements */}
        <div className="absolute top-20 right-20 opacity-20 animate-float">
          <Bike className="w-20 h-20 text-primary animate-glow-pulse" />
        </div>
        <div className="absolute bottom-32 left-16 opacity-15 animate-float" style={{ animationDelay: "2s" }}>
          <Bike className="w-14 h-14 text-secondary" />
        </div>
        <div className="absolute top-1/3 left-10 opacity-10 animate-float" style={{ animationDelay: "1s" }}>
          <Bike className="w-10 h-10 text-accent" />
        </div>
        
        {/* Grid lines */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(hsl(var(--primary) / 0.3) 1px, transparent 1px),
                              linear-gradient(90deg, hsl(var(--primary) / 0.3) 1px, transparent 1px)`,
            backgroundSize: "80px 80px"
          }} />
        </div>
      </div>

      <div className={`w-full max-w-md relative z-10 px-4 ${isTransitioning ? "animate-bike-ignition" : "animate-scale-in"}`}>
        {/* Logo and header */}
        <div className="text-center mb-10">
          <div className={`inline-flex items-center justify-center w-24 h-24 rounded-2xl mb-6 glass-card neon-blue ${isLoading ? "" : ""}`}>
            <Bike className={`w-12 h-12 text-primary ${isLoading ? "animate-wheel-spin" : "animate-glow-pulse"}`} />
          </div>
          <h1 className="text-5xl font-extrabold text-foreground mb-3 tracking-tight">
            <span className="text-gradient-primary">Ride</span>
            <span className="text-foreground">Wise</span>
          </h1>
          <p className="text-lg text-muted-foreground flex items-center justify-center gap-2">
            <Zap className="w-4 h-4 text-accent" />
            Ride Smarter. Plan Better.
            <Zap className="w-4 h-4 text-accent" />
          </p>
        </div>

        {/* Login card */}
        <div className="glass-card rounded-2xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-xl font-bold text-foreground">Welcome Back</h2>
            <p className="text-sm text-muted-foreground mt-2">Sign in to access your intelligence hub</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-medium text-foreground">
                Username
              </Label>
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-11 h-12 bg-muted/50 border-border hover:border-primary/50 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-foreground">
                Password
              </Label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-11 pr-11 h-12 bg-muted/50 border-border hover:border-primary/50 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full h-14 gradient-primary text-primary-foreground font-bold text-lg shadow-glow hover:shadow-hover transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] btn-glow"
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center gap-3">
                  <Bike className="w-6 h-6 animate-wheel-spin" />
                  Igniting...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Start Your Ride
                </span>
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              Demo mode • Use any credentials to continue
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 space-y-2">
          <p className="text-xs text-muted-foreground">
            AI-Powered Demand Intelligence • Real-time Analytics
          </p>
          <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground/60">
            <span>Smart Mobility</span>
            <span className="w-1 h-1 rounded-full bg-primary/50" />
            <span>Enterprise Ready</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
