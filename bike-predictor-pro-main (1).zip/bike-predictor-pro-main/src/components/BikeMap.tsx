import { useState, useEffect } from "react";
import { Bike, MapPin, Flame } from "lucide-react";

interface BikeLocation {
  id: number;
  x: number;
  y: number;
  status: "available" | "in-use" | "high-demand";
  moving?: boolean;
}

interface HeatZone {
  x: number;
  y: number;
  intensity: number;
}

const BikeMap = () => {
  const [bikes, setBikes] = useState<BikeLocation[]>([]);
  const [heatZones] = useState<HeatZone[]>([
    { x: 25, y: 30, intensity: 0.8 },
    { x: 65, y: 45, intensity: 0.9 },
    { x: 45, y: 70, intensity: 0.6 },
    { x: 80, y: 25, intensity: 0.7 },
  ]);

  // Initialize bike positions
  useEffect(() => {
    const initialBikes: BikeLocation[] = [
      { id: 1, x: 20, y: 25, status: "available" },
      { id: 2, x: 35, y: 40, status: "in-use", moving: true },
      { id: 3, x: 55, y: 30, status: "available" },
      { id: 4, x: 70, y: 50, status: "high-demand" },
      { id: 5, x: 45, y: 65, status: "in-use", moving: true },
      { id: 6, x: 25, y: 55, status: "available" },
      { id: 7, x: 60, y: 75, status: "high-demand" },
      { id: 8, x: 80, y: 35, status: "available" },
      { id: 9, x: 15, y: 70, status: "in-use", moving: true },
      { id: 10, x: 50, y: 20, status: "available" },
      { id: 11, x: 75, y: 65, status: "high-demand" },
      { id: 12, x: 30, y: 80, status: "available" },
    ];
    setBikes(initialBikes);
  }, []);

  // Animate moving bikes
  useEffect(() => {
    const interval = setInterval(() => {
      setBikes((prev) =>
        prev.map((bike) => {
          if (bike.moving) {
            return {
              ...bike,
              x: bike.x + (Math.random() - 0.5) * 2,
              y: bike.y + (Math.random() - 0.5) * 2,
            };
          }
          return bike;
        })
      );
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: BikeLocation["status"]) => {
    switch (status) {
      case "available":
        return "bg-status-available";
      case "in-use":
        return "bg-status-in-use";
      case "high-demand":
        return "bg-status-high-demand";
    }
  };

  return (
    <div className="relative w-full h-[400px] bg-muted/30 rounded-xl overflow-hidden border border-border/50">
      {/* Map background with grid */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(to right, hsl(var(--border)) 1px, transparent 1px),
              linear-gradient(to bottom, hsl(var(--border)) 1px, transparent 1px)
            `,
            backgroundSize: "40px 40px",
          }}
        />
        
        {/* City blocks simulation */}
        <div className="absolute top-[10%] left-[10%] w-[25%] h-[20%] bg-muted/50 rounded-lg" />
        <div className="absolute top-[40%] left-[5%] w-[20%] h-[25%] bg-muted/50 rounded-lg" />
        <div className="absolute top-[20%] left-[50%] w-[30%] h-[15%] bg-muted/50 rounded-lg" />
        <div className="absolute top-[55%] left-[40%] w-[35%] h-[20%] bg-muted/50 rounded-lg" />
        <div className="absolute top-[15%] right-[5%] w-[15%] h-[30%] bg-muted/50 rounded-lg" />
        <div className="absolute bottom-[10%] left-[15%] w-[25%] h-[15%] bg-muted/50 rounded-lg" />
        <div className="absolute bottom-[5%] right-[10%] w-[20%] h-[25%] bg-muted/50 rounded-lg" />
        
        {/* Roads */}
        <div className="absolute top-[35%] left-0 right-0 h-[3%] bg-muted/70" />
        <div className="absolute top-[65%] left-0 right-0 h-[2%] bg-muted/70" />
        <div className="absolute top-0 bottom-0 left-[35%] w-[2%] bg-muted/70" />
        <div className="absolute top-0 bottom-0 right-[25%] w-[3%] bg-muted/70" />
      </div>

      {/* Heat zones (demand overlay) */}
      {heatZones.map((zone, index) => (
        <div
          key={index}
          className="absolute rounded-full transition-all duration-1000"
          style={{
            left: `${zone.x}%`,
            top: `${zone.y}%`,
            width: `${zone.intensity * 120}px`,
            height: `${zone.intensity * 120}px`,
            transform: "translate(-50%, -50%)",
            background: `radial-gradient(circle, hsl(var(--status-high-demand) / ${zone.intensity * 0.3}) 0%, transparent 70%)`,
          }}
        />
      ))}

      {/* Bike markers */}
      {bikes.map((bike) => (
        <div
          key={bike.id}
          className={`absolute transition-all duration-2000 ease-linear ${bike.moving ? "animate-bike-move" : ""}`}
          style={{
            left: `${bike.x}%`,
            top: `${bike.y}%`,
            transform: "translate(-50%, -50%)",
          }}
        >
          <div
            className={`relative p-1.5 rounded-full ${getStatusColor(bike.status)} shadow-lg`}
          >
            <Bike className="w-4 h-4 text-white" />
            {bike.status === "high-demand" && (
              <Flame className="absolute -top-1 -right-1 w-3 h-3 text-orange-400 animate-pulse" />
            )}
          </div>
        </div>
      ))}

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm rounded-lg p-3 shadow-lg border border-border/50">
        <p className="text-xs font-medium text-foreground mb-2">Bike Status</p>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-status-available" />
            <span className="text-xs text-muted-foreground">Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-status-in-use" />
            <span className="text-xs text-muted-foreground">In Use</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-status-high-demand" />
            <span className="text-xs text-muted-foreground">High Demand</span>
          </div>
        </div>
      </div>

      {/* Station markers */}
      <div className="absolute top-[20%] left-[22%]">
        <MapPin className="w-5 h-5 text-primary drop-shadow-md" />
      </div>
      <div className="absolute top-[50%] left-[65%]">
        <MapPin className="w-5 h-5 text-primary drop-shadow-md" />
      </div>
      <div className="absolute top-[75%] left-[40%]">
        <MapPin className="w-5 h-5 text-primary drop-shadow-md" />
      </div>
    </div>
  );
};

export default BikeMap;
