import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Bike, User, Zap, HardHat } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Message {
  id: number;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hey! 👋 I'm your RideWise AI assistant. Ask me about demand predictions, peak hours, or let me help you navigate. What's on your mind?",
      isBot: true,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getBotResponse = (userMessage: string): { text: string; action?: () => void } => {
    const msg = userMessage.toLowerCase();

    if (msg.includes("hourly") && (msg.includes("demand") || msg.includes("prediction") || msg.includes("show"))) {
      return {
        text: "Let's check the hourly patterns! 🕐 Taking you to the Hourly Prediction view where our AI analyzes demand by the hour.",
        action: () => navigate("/hourly"),
      };
    }

    if (msg.includes("daily") && (msg.includes("demand") || msg.includes("prediction") || msg.includes("show"))) {
      return {
        text: "Great choice! 📅 Opening the Daily Forecast view. Perfect for strategic fleet planning.",
        action: () => navigate("/daily"),
      };
    }

    if (msg.includes("dashboard") || msg.includes("home") || msg.includes("overview")) {
      return {
        text: "Heading to your command center! 📊 The Dashboard has all your real-time metrics.",
        action: () => navigate("/dashboard"),
      };
    }

    if (msg.includes("peak") && (msg.includes("time") || msg.includes("hour") || msg.includes("demand"))) {
      return {
        text: "📈 Peak Demand Analysis:\n\n🌅 Morning Rush: 7-9 AM\n→ Commuters heading to work\n\n🌆 Evening Rush: 5-7 PM\n→ Return commute peak\n\n🎯 Weekends: Noon-3 PM\n→ Leisure riders\n\nCheck Hourly Prediction for your specific data!",
      };
    }

    if (msg.includes("weather") || msg.includes("rain") || msg.includes("temperature")) {
      return {
        text: "🌤️ Weather Impact Insights:\n\n☀️ Clear skies → +25% demand\n🌧️ Rain → -50% demand\n🌡️ Sweet spot: 18-25°C\n❄️ Cold below 5°C → -40%\n\nOur AI factors these in automatically!",
      };
    }

    if (msg.includes("map") || msg.includes("location") || msg.includes("bikes")) {
      return {
        text: "🗺️ Live Map Legend:\n\n🟢 Available bikes\n🟠 In-use / Moving\n🔴 High-demand zones\n\nHeat overlays show demand intensity. Check the Dashboard for the live view!",
      };
    }

    if (msg.includes("accuracy") || msg.includes("model") || msg.includes("ai") || msg.includes("how")) {
      return {
        text: "🧠 RideWise AI Engine:\n\n✓ 94.2% prediction accuracy\n✓ Trained on 100K+ data points\n✓ Factors: weather, time, events, history\n✓ Real-time model updates\n\nEnterprise-grade intelligence!",
      };
    }

    if (msg.includes("help") || msg.includes("what can you do") || msg.includes("features")) {
      return {
        text: "I'm your AI copilot! Here's what I do:\n\n🗺️ Navigate anywhere in the app\n📈 Explain predictions & trends\n⏰ Share peak demand insights\n🌤️ Discuss weather impacts\n🧠 Explain how our AI works\n\nJust ask naturally!",
      };
    }

    if (msg.includes("hello") || msg.includes("hi") || msg.includes("hey")) {
      return {
        text: "Hey there! 🚴 Ready to ride smarter? Ask me about demand predictions, peak hours, or let me navigate you anywhere!",
      };
    }

    if (msg.includes("thank")) {
      return {
        text: "Anytime! 🙌 That's what I'm here for. Ride smart! 🚴‍♂️",
      };
    }

    return {
      text: "I can help with:\n\n• 📊 Hourly/Daily predictions\n• ⏰ Peak demand times\n• 🌤️ Weather effects\n• 🗺️ App navigation\n• 🧠 AI insights\n\nWhat would you like to explore?",
    };
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: input,
      isBot: false,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    await new Promise((resolve) => setTimeout(resolve, 800));

    const response = getBotResponse(input);
    
    const botMessage: Message = {
      id: messages.length + 2,
      text: response.text,
      isBot: true,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, botMessage]);
    setIsTyping(false);

    if (response.action) {
      setTimeout(() => {
        response.action!();
        setIsOpen(false);
      }, 1200);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating button - Bike helmet style */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-50 p-4 rounded-full shadow-glow hover:shadow-hover transition-all duration-300 hover:scale-110 ${
          isOpen ? "bg-muted rotate-180" : "gradient-primary animate-pulse-glow"
        }`}
      >
        {isOpen ? (
          <X className="w-6 h-6 text-foreground" />
        ) : (
          <div className="relative">
            <HardHat className="w-6 h-6 text-primary-foreground" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full animate-pulse" />
          </div>
        )}
      </button>

      {/* Chat panel */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-[400px] max-w-[calc(100vw-3rem)] glass-card rounded-2xl overflow-hidden animate-scale-in">
          {/* Header */}
          <div className="bg-gradient-to-r from-primary/20 to-secondary/20 p-4 flex items-center gap-3 border-b border-border/50">
            <div className="p-2.5 rounded-xl bg-primary/20 border border-primary/30">
              <Bike className="w-5 h-5 text-primary animate-glow-pulse" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-foreground flex items-center gap-2">
                RideWise AI
                <Zap className="w-3 h-3 text-accent" />
              </h3>
              <p className="text-xs text-muted-foreground">Your intelligent copilot</p>
            </div>
            <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-secondary/20">
              <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
              <span className="text-[10px] text-secondary font-medium">Online</span>
            </div>
          </div>

          {/* Messages */}
          <div className="h-[380px] overflow-y-auto p-4 space-y-4 bg-background/30">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.isBot ? "" : "flex-row-reverse"} animate-slide-up`}
              >
                <div
                  className={`p-2 rounded-xl h-fit ${
                    message.isBot ? "bg-primary/10 border border-primary/20" : "gradient-primary"
                  }`}
                >
                  {message.isBot ? (
                    <Bike className="w-4 h-4 text-primary" />
                  ) : (
                    <User className="w-4 h-4 text-primary-foreground" />
                  )}
                </div>
                <div
                  className={`max-w-[75%] p-3 rounded-2xl ${
                    message.isBot
                      ? "bg-muted/50 text-foreground border border-border/50 rounded-tl-none"
                      : "gradient-primary text-primary-foreground rounded-tr-none"
                  }`}
                >
                  <p className="text-sm whitespace-pre-line leading-relaxed">{message.text}</p>
                  <p className={`text-[10px] mt-2 ${message.isBot ? "text-muted-foreground" : "text-primary-foreground/70"}`}>
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-3 animate-fade-in">
                <div className="p-2 rounded-xl bg-primary/10 border border-primary/20">
                  <Bike className="w-4 h-4 text-primary animate-pulse" />
                </div>
                <div className="bg-muted/50 p-4 rounded-2xl rounded-tl-none border border-border/50">
                  <div className="flex gap-1.5">
                    <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border/50 bg-card/50">
            <div className="flex gap-2">
              <Input
                placeholder="Ask about predictions, peaks..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1 bg-muted/50 border-border focus:border-primary"
              />
              <Button
                onClick={handleSend}
                size="icon"
                disabled={!input.trim() || isTyping}
                className="gradient-primary hover:shadow-glow transition-all"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground mt-2 text-center">
              Try: "Show hourly demand" • "Peak times?" • "Weather effects"
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
