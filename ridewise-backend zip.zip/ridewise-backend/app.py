from dotenv import load_dotenv
load_dotenv()

from flask import Flask
from flask_cors import CORS
from routes.predict import predict_bp
from routes.chatbot import chatbot_bp
from routes.parser import parser_bp


app = Flask(__name__)
CORS(app)

app.register_blueprint(predict_bp, url_prefix="/api")
app.register_blueprint(chatbot_bp, url_prefix="/api")
app.register_blueprint(parser_bp, url_prefix="/api")

@app.route("/")
def home():
    return "RideWise API is running"

if __name__ == "__main__":
    app.run(debug=True)
