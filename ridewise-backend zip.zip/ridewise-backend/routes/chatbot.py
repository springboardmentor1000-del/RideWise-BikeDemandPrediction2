from flask import Blueprint, request, jsonify
import google.generativeai as genai
import os

chatbot_bp = Blueprint('chatbot', __name__)

genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel("gemini-2.0-flash")

@chatbot_bp.route("/chat", methods=["POST"])
def chat():
    data = request.json

    message = data.get("message", "")
    language = data.get("language", "en")

    lang_instruction = {
        "en": "Reply in English.",
        "hi": "Reply in simple Hindi.",
        "kn": "Reply in simple Kannada."
    }.get(language, "Reply in English.")

    prompt = f"""
    You are RideWise AI Assistant for bike rentals.
    Explain demand patterns, peak hours, weather impact simply.
    
    {lang_instruction}

    User question: {message}
    """

    try:
        response = model.generate_content(prompt)
        return jsonify({
            "reply": response.text.strip()
        })
    except Exception as e:
        return jsonify({
            "error": "Gemini temporarily unavailable",
            "details": str(e)
        }), 500
