from flask import Blueprint, request, jsonify
import numpy as np
import pickle
import os

predict_bp = Blueprint("predict", __name__)

# -------------------------------------------------
# LOAD MODEL & FEATURES ONCE (VERY IMPORTANT)
# -------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

MODEL_PATH = os.path.join(BASE_DIR, "ml", "hourly_model.pkl")
FEATURE_PATH = os.path.join(BASE_DIR, "ml", "hourly_features.pkl")

with open(MODEL_PATH, "rb") as f:
    hourly_model = pickle.load(f)

with open(FEATURE_PATH, "rb") as f:
    hourly_features = pickle.load(f)  # list of feature names


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def encode_inputs(season, weather, working_day, temperature, hour):
    """
    Build feature vector exactly in training order
    """
    feature_dict = {f: 0 for f in hourly_features}

    # numeric
    feature_dict["temp"] = temperature
    feature_dict["hr"] = hour

    # categorical encoding
    feature_dict[f"season_{season}"] = 1
    feature_dict[f"weathersit_{weather}"] = 1
    feature_dict[f"workingday_{1 if working_day == 'yes' else 0}"] = 1

    return np.array([feature_dict[f] for f in hourly_features])


# -------------------------------------------------
# HOURLY PREDICTION API (REAL MODEL)
# -------------------------------------------------
@predict_bp.route("/predict/hourly", methods=["POST"])
def hourly_prediction():
    try:
        data = request.get_json()

        season = data["season"]
        weather = data["weather"]
        working_day = data["workingDay"]
        temperature = float(data["temperature"])

        hourlyData = []
        totalDemand = 0
        peakHour = {"label": "", "value": 0}

        for hour in range(24):
            X = encode_inputs(
                season, weather, working_day, temperature, hour
            ).reshape(1, -1)

            prediction = int(hourly_model.predict(X)[0])
            prediction = max(prediction, 0)

            label = f"{hour:02d}:00"

            hourlyData.append({
                "label": label,
                "value": prediction
            })

            totalDemand += prediction

            if prediction > peakHour["value"]:
                peakHour = {
                    "label": label,
                    "value": prediction
                }

        return jsonify({
            "hourlyData": hourlyData,
            "peakHour": peakHour,
            "totalDemand": totalDemand
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500
