from flask import Blueprint, request, jsonify
import csv
import io
from datetime import datetime
import re

parser_bp = Blueprint("parser", __name__)

# ---------- Helpers ----------

def parse_hour(value):
    if value is None:
        return None

    value = str(value).strip().lower()

    try:
        if value.isdigit():
            hour = int(value)
            return hour if 0 <= hour <= 23 else None

        if ":" in value:
            hour = int(value.split(":")[0])
            return hour if 0 <= hour <= 23 else None

        match = re.match(r"(\d{1,2})\s*(am|pm)", value)
        if match:
            hour = int(match.group(1))
            period = match.group(2)

            if hour < 1 or hour > 12:
                return None

            if period == "pm" and hour != 12:
                hour += 12
            if period == "am" and hour == 12:
                hour = 0

            return hour
    except:
        return None

    return None


def parse_date(value):
    if not value:
        return None

    formats = [
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%d/%m/%Y",
        "%Y/%m/%d",
        "%d %b %Y",
        "%d %B %Y"
    ]

    for fmt in formats:
        try:
            return datetime.strptime(value.strip(), fmt).date().isoformat()
        except:
            continue

    return None


# ---------- API ----------

@parser_bp.route("/parse/csv", methods=["POST"])
def parse_csv():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]

    if not file.filename.endswith(".csv"):
        return jsonify({"error": "Only CSV files allowed"}), 400

    stream = io.StringIO(file.stream.read().decode("utf-8"))
    reader = csv.DictReader(stream)
    rows = list(reader)

    if not rows:
        return jsonify({"error": "CSV is empty"}), 400

    hourly_demand = {}
    daily_demand = {}
    total_demand = 0
    invalid_rows = 0

    for row in rows:
        raw_hour = row.get("hour")
        raw_cnt = row.get("cnt")
        raw_date = row.get("date")

        hour = parse_hour(raw_hour)
        date = parse_date(raw_date)

        try:
            cnt = int(float(raw_cnt))
        except:
            cnt = None

        if hour is None or cnt is None:
            invalid_rows += 1
            continue

        hourly_demand[hour] = hourly_demand.get(hour, 0) + cnt

        if date:
            daily_demand[date] = daily_demand.get(date, 0) + cnt

        total_demand += cnt

    if not hourly_demand:
        return jsonify({"error": "No valid rows found"}), 400

    peak_hour = max(hourly_demand, key=hourly_demand.get)

    response = {
        "columns": reader.fieldnames,
        "rows_received": len(rows),
        "rows_used": len(rows) - invalid_rows,
        "invalid_rows": invalid_rows,
        "total_demand": total_demand,
        "hourly_demand": dict(sorted(hourly_demand.items())),
        "peak_hour": {
            "hour": peak_hour,
            "demand": hourly_demand[peak_hour]
        }
    }

    if daily_demand:
        peak_day = max(daily_demand, key=daily_demand.get)
        response["daily_demand"] = daily_demand
        response["peak_day"] = {
            "date": peak_day,
            "demand": daily_demand[peak_day]
        }

    return jsonify(response)
